package com.traininfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
