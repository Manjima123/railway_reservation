package com.bookinginfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
